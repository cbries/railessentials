;jQuery(function($) {
	$.colorpicker.regional['es'] = {
		ok:				'OK',
		cancel:			'Cancelar',
		none:			'Ninguno',
		button:			'Color',
		title:			'Selecciona un color',
		transparent:	'Transparente',
		hsvH:			'H',
		hsvS:			'S',
		hsvV:			'V',
		rgbR:			'R',
		rgbG:			'G',
		rgbB:			'B',
		labL:			'L',
		labA:			'a',
		labB:			'b',
		hslH:			'H',
		hslS:			'S',
		hslL:			'L',
		cmykC:			'C',
		cmykM:			'M',
		cmykY:			'Y',
		cmykK:			'K',
		alphaA:			'A'
	};
});