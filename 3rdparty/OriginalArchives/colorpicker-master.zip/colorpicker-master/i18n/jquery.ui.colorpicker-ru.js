;jQuery(function($) {
	$.colorpicker.regional['ru'] = {
		ok:			'OK',
		cancel:			'Отменить',
		none:			'Никакой',
		button:			'Цвет',
		title:			'Выбрать цвет',
		transparent:	        'Прозрачный',
		hsvH:			'H',
		hsvS:			'S',
		hsvV:			'V',
		rgbR:			'R',
		rgbG:			'G',
		rgbB:			'B',
		labL:			'L',
		labA:			'a',
		labB:			'b',
		hslH:			'H',
		hslS:			'S',
		hslL:			'L',
		cmykC:			'C',
		cmykM:			'M',
		cmykY:			'Y',
		cmykK:			'K',
		alphaA:			'A'
	};
});