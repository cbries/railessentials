﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SuperSocket.Agent")]
[assembly: AssemblyDescription("SuperSocket.Agent")]
[assembly: ComVisible(false)]
[assembly: Guid("bae8bfe5-07a0-47aa-9e2d-9e2a5e8bf068")]
