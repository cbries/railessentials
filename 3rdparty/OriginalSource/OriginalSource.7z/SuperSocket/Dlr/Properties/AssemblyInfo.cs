﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("SuperSocket.Dlr")]
[assembly: AssemblyDescription("SuperSocket.Dlr")]
[assembly: AssemblyConfiguration("")]
[assembly: ComVisible(false)]
[assembly: Guid("b80547cb-07f8-4873-8abb-aef72949aab2")]
