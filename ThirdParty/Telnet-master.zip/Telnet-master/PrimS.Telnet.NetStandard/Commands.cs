﻿namespace PrimS.Telnet
{
  [IsNotDeadCodeAttribute]
  internal enum Commands
  {
    Will = 251,
    Wont = 252,
    Do = 253,
    Dont = 254,
    InterpretAsCommand = 255
  }
}