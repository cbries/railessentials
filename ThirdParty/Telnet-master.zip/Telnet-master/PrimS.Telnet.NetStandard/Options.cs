namespace PrimS.Telnet
{
  [IsNotDeadCodeAttribute]
  internal enum Options
  {
    SuppressGoAhead = 3
  }
}